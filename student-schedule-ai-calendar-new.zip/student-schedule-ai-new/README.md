# StudentSchedule AI — Calendar Edition

A clean static version with separate left-side tabs:
- Today
- Calendar (monthly)
- Tasks
- Week
- Planner AI (chatbot only)
- Settings

Includes a 3-day Pro trial UI. The payment button is a placeholder until a parent/guardian connects a real payment checkout.

Upload the three files inside `public/` to the root of your GitHub Pages repository.
