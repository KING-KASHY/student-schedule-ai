# Student Schedule AI Interactive

An interactive web application designed to help students manage and optimize their schedules using AI assistance.

## Project Structure
- `public/index.html`: Main user interface.
- `public/style.css`: Styling and layout.
- `public/app.js`: Core interactivity and logic.
