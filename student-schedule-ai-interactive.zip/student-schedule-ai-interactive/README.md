# StudentSchedule AI Interactive Edition

Upload ONLY these three files from `public/` to the root of your GitHub Pages repository:
- index.html
- app.js
- style.css

This version adds a separate AI Assistant tab. Planner AI is only for schedule changes.

Important: the AI Assistant is a local rule-based assistant because GitHub Pages is static. It is designed to feel more conversational, but it is not actually ChatGPT and has no live internet or cloud model. A true ChatGPT-like assistant requires a backend/API.

The 3-day trial UI is included. Payment checkout is intentionally not hard-coded because a real payment processor/account needs to be connected, and because the user is a minor, payment/payout setup should be handled by a parent/guardian.
